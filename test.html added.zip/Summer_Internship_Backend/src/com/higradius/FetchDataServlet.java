package com.higradius;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.Gson;

@WebServlet("/FetchDataServlet")
public class FetchDataServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
    
//	MySQL Driver for JDBC
	static final String JDBC_DRIVER = "com.mysql.jdbc.Driver";
	
//	Connection Parameters
	static final String URL = "jdbc:mysql://localhost:3306/h2hbabba2746";
	private static final String USER = "root";
	private static final String PASS = "1001";

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		
//		Getting the Page Number
		String page_url = request.getPathInfo();
		int page = (Integer.parseInt(page_url.substring(1, page_url.length()))-1)*11;
		System.out.println(page);
		
//		Initialising ArrayList for Storing Data
		ArrayList<Response> invList = new ArrayList<>();

		try {
			
//			Registering Driver
			Class.forName(JDBC_DRIVER);
			
//			Creating Connection
			Connection con = DriverManager.getConnection(URL, USER, PASS);
		
//			Creating Statement
			Statement st = con.createStatement();
			
//			Sending Query and Storing Result in Resultset
			String query = "SELECT * FROM data LIMIT "+page+",11";
			ResultSet rs = st.executeQuery(query);
			
//			Changing the results from ResultSet to ArrayList
			int count = 0;
			while(rs.next()) {
				Response inv= new Response();
				inv.setName_customer(rs.getString("name_customer"));
				inv.setCust_number(rs.getString("cust_number"));
				inv.setInvoice_id(rs.getLong("invoice_id"));
				inv.setTotal_open_amount(rs.getFloat("total_open_amount"));
				inv.setDue_in_date(rs.getString("due_in_date"));
				inv.setPred_payment_date(rs.getString("pred_payment_date"));
				inv.setNotes(rs.getString("notes"));
				invList.add(inv);
				count++;
			}
			System.out.println("Number of Datas Fetched = " + count);
			
//			Converting ArrayList to JSON using GSON Builder
			Gson gson = new Gson();
			String data = gson.toJson(invList);
			PrintWriter out = response.getWriter();
			response.setContentType("application/json");
			response.setCharacterEncoding("UTF-8");
			out.write(data);
			out.flush();
			
//			Close Connection
			st.close();
			con.close();
			
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		
	}


}

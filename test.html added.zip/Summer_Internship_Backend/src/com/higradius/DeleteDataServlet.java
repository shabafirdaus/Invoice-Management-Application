package com.higradius;

import java.sql.*;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/DeleteDataServlet")
public class DeleteDataServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
    
//	MySQL Driver for JDBC
	static final String JDBC_DRIVER = "com.mysql.jdbc.Driver";
	
//	Connection Parameters
	static final String URL = "jdbc:mysql://localhost:3306/h2hbabba2746";
	private static final String USER = "root";
	private static final String PASS = "1001";
       
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
//		Getting invoices to delete from request
		String str_invList = request.getParameter("delete_data");
		
//		Splitting the invoices
		String[] strList_invList = str_invList.split(",");

//		Convering invoice_ids to float
		float[] floatList_invList = new float[strList_invList.length];
		for (int i=0;i<strList_invList.length; i++) {
			floatList_invList[i] = Float.parseFloat(strList_invList[i]);
		}
		
		
		try {
			
//			Registering Driver
			Class.forName(JDBC_DRIVER);
			
//			Creating Connection
			Connection con = DriverManager.getConnection(URL, USER, PASS);
		
//			Creating Statement
			Statement st = con.createStatement();
			
//			Sending Query and Deleting Data
			for (int i=0; i<floatList_invList.length; i++) {
				String query = "DELETE FROM data WHERE invoice_id="+floatList_invList[i];
				System.out.println(query);
				st.executeUpdate(query);
			}
			
//			Close Connection
			st.close();
			con.close();
			
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		
//		Redirecting to index.html
		response.sendRedirect("index.html");
		
	}

}

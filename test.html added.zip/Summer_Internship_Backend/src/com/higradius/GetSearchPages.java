package com.higradius;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.Gson;

@WebServlet("/GetSearchPages")
public class GetSearchPages extends HttpServlet {
	private static final long serialVersionUID = 1L;
    
//	MySQL Driver for JDBC
	static final String JDBC_DRIVER = "com.mysql.jdbc.Driver";
	
//	Connection Parameters
	static final String URL = "jdbc:mysql://localhost:3306/h2hbabba2746";
	private static final String USER = "root";
	private static final String PASS = "1001";
       
    
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

//		Getting the Page Number
		String page_url = request.getPathInfo();
		String search = page_url.substring(1, page_url.length());

//		Initialising ArrayList for Storing Data
		ArrayList<Page> pages = new ArrayList<>();
		
		try {
			
//			Registering Driver
			Class.forName(JDBC_DRIVER);
			
//			Creating Connection
			Connection con = DriverManager.getConnection(URL, USER, PASS);
		
//			Creating Statement
			Statement st = con.createStatement();
			
//			Sending Query and Storing Result in Resultset
			String query = "SELECT COUNT(invoice_id) FROM data WHERE invoice_id LIKE '"+ search +"%'";
			ResultSet rs = st.executeQuery(query);
			rs.next();
			
			System.out.println(rs.getInt(1)%11 == 0 ? rs.getInt(1)/11 : (rs.getInt(1)/11)+1);
			Page pg = new Page();
			pg.setPage(rs.getInt(1)%11 == 0 ? rs.getInt(1)/11 : (rs.getInt(1)/11)+1);
			pages.add(pg);
			
//			Converting ArrayList to JSON using GSON Builder
			Gson gson = new Gson();
			String data = gson.toJson(pages);
			PrintWriter out = response.getWriter();
			response.setContentType("application/json");
			response.setCharacterEncoding("UTF-8");
			out.write(data);
			out.flush();
			
//			Close Connection
			st.close();
			con.close();
	
			
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
	}
}

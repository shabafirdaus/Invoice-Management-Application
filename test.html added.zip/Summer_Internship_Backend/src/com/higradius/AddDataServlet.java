package com.higradius;

import java.sql.*;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/AddDataServlet")
public class AddDataServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
    
//	MySQL Driver for JDBC
	static final String JDBC_DRIVER = "com.mysql.jdbc.Driver";
	
//	Connection Parameters
	static final String URL = "jdbc:mysql://localhost:3306/h2hbabba2746";
	private static final String USER = "root";
	private static final String PASS = "1001";

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

//		Getting data from request
		String cust_name = request.getParameter("add_cust_name");
		String cust_number = request.getParameter("add_cust_number");
		String str_invoice_no = request.getParameter("add_invoice_no");
		String str_invoice_amount = request.getParameter("add_invoice_amount");
		String str_due_in_date = request.getParameter("add_due_in_date");
		String notes = request.getParameter("add_notes");
		
//		Changing Datatypes as per Database
		float invoice_no = Float.parseFloat(str_invoice_no);
		float invoice_amount = Float.parseFloat(str_invoice_amount.substring(1, str_invoice_amount.length()));
		Date due_in_date = Date.valueOf(str_due_in_date);
		
		System.out.println(cust_name + " " + cust_number + " " + invoice_no + " " + invoice_amount + " " + due_in_date + " " + notes);

		try {
			
//			Registering Driver
			Class.forName(JDBC_DRIVER);
			
//			Creating Connection
			Connection con = DriverManager.getConnection(URL, USER, PASS);
		
//			Creating Statement
			Statement st = con.createStatement();
			
//			Sending Query and Inserting Data
			String query = "INSERT INTO data VALUES ('"+ cust_name +"', '"+ cust_number +"', "+ invoice_no +", "+ invoice_amount +", '"+ due_in_date +"', NULL, "+ (notes == "" ? "NULL" : "'"+notes+"'") +")";
			System.out.print(query);
			st.executeUpdate(query);

//			Close Connection
			st.close();
			con.close();
			
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		
//		Redirecting to index.html
		response.sendRedirect("index.html");
		
	}

}

package com.higradius;

public class Response {
	
//	Class Variables
	private String name_customer;
	private String cust_number;
	private Long invoice_id;
	private Float total_open_amount;
	private String due_in_date;
	private String pred_payment_date;
	private String notes;
	
//	Getter and Setter Methods
	public String getName_customer() {
		return name_customer;
	}
	public void setName_customer(String name_customer) {
		this.name_customer = name_customer;
	}
	public String getCust_number() {
		return cust_number;
	}
	public void setCust_number(String cust_number) {
		this.cust_number = cust_number;
	}
	public Long getInvoice_id() {
		return invoice_id;
	}
	public void setInvoice_id(Long invoice_id) {
		this.invoice_id = invoice_id;
	}
	public Float getTotal_open_amount() {
		return total_open_amount;
	}
	public void setTotal_open_amount(Float total_open_amount) {
		this.total_open_amount = total_open_amount;
	}
	public String getDue_in_date() {
		return due_in_date;
	}
	public void setDue_in_date(String due_in_date) {
		this.due_in_date = due_in_date;
	}
	public String getPred_payment_date() {
		return pred_payment_date;
	}
	public void setPred_payment_date(String pred_payment_date) {
		this.pred_payment_date = pred_payment_date;
	}
	public String getNotes() {
		return notes;
	}
	public void setNotes(String notes) {
		this.notes = notes;
	}
	
}

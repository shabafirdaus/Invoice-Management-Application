package com.higradius;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class EditDataServlet
 */
@WebServlet("/EditDataServlet")
public class EditDataServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
    
//	MySQL Driver for JDBC
	static final String JDBC_DRIVER = "com.mysql.jdbc.Driver";
	
//	Connection Parameters
	static final String URL = "jdbc:mysql://localhost:3306/h2hbabba2746";
	private static final String USER = "root";
	private static final String PASS = "1001";
       
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
//		Getting data from request
		String str_invoice_no = request.getParameter("edit_invoice_no");
		String str_invoice_amount = request.getParameter("edit_invoice_amount");
		String notes = request.getParameter("edit_notes");
		
//		Changing Datatypes as per Database
		int int_invoice_no = Integer.parseInt(str_invoice_no);
		float invoice_amount = Float.parseFloat(str_invoice_amount.substring(1, str_invoice_amount.length()));
		System.out.println(str_invoice_no + " " + int_invoice_no);
		
		try {
			
//			Registering Driver
			Class.forName(JDBC_DRIVER);
			
//			Creating Connection
			Connection con = DriverManager.getConnection(URL, USER, PASS);
		
//			Creating Statement
			Statement st = con.createStatement();
			
//			Sending Query and Updating Data
			String query = "UPDATE data SET total_open_amount = "+invoice_amount+", notes = "+ (notes == "" ? "NULL" : "'"+notes+"'") +" WHERE invoice_id="+int_invoice_no;
			System.out.print(query);
			st.executeUpdate(query);

//			Close Connection
			st.close();
			con.close();
			
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		
//		Redirecting to index.html
		response.sendRedirect("index.html");
		
		
		
	}

}

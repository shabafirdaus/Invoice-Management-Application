// Initialising Array for storing selected data
var selected = [];

// Add single data to selected[]
function addData(i) {
    selected.push({key: i, page: page, data: data[i]});
    checkButtons()
    console.log(selected);
    document.getElementsByClassName('data_row')[i].style.backgroundColor = "#2A5368"
    document.getElementsByClassName('unchecked')[i+1].style.display = "none"
    document.getElementsByClassName('checked')[i+1].style.display = "block"
}
// Add all the page datas to selected[]
function addAll(){
    for (let i = 0; i < data.length; i++) {
        selected.push({key: i, page: page, data: data[i]})
    }
    
    checkButtons()
    console.log(selected)
    document.getElementsByClassName('unchecked')[0].style.display = "none"
    document.getElementsByClassName('checked')[0].style.display = "block"
    
    for (let i = 0; i < data.length; i++) {
        document.getElementsByClassName('data_row')[i].style.backgroundColor = "#2A5368"
        document.getElementsByClassName('unchecked')[i+1].style.display = "none"
        document.getElementsByClassName('checked')[i+1].style.display = "block"
    }
}
// Delete single data from selected[]
function delData(i) {
    document.getElementsByClassName('unchecked')[0].style.display = "block"
    document.getElementsByClassName('checked')[0].style.display = "none"
    var ind = null;
    for (let idx = 0; idx < selected.length; idx++) {
        if (selected[idx]["key"] == i && selected[idx]["page"] == page) {
            console.log(idx)
            ind = idx
            break;
        }
    }
    if (ind != null) {
        selected.splice(ind, 1)
        console.log(selected);
        if(i%2 == 0) document.getElementsByClassName('data_row')[i].style.backgroundColor = "initial"
        else document.getElementsByClassName('data_row')[i].style.backgroundColor = "#283A46"
        document.getElementsByClassName('unchecked')[i+1].style.display = "block"
        document.getElementsByClassName('checked')[i+1].style.display = "none"
    }
    checkButtons()
    
}
// Delete all datas from selected[]
function delAll(){
    selected = []
    checkButtons()
    console.log(selected)
    document.getElementsByClassName('unchecked')[0].style.display = "block"
    document.getElementsByClassName('checked')[0].style.display = "none"
    
    for (let i = 0; i < data.length; i++) {
        if(i%2 == 0) document.getElementsByClassName('data_row')[i].style.backgroundColor = "initial"
        else document.getElementsByClassName('data_row')[i].style.backgroundColor = "#283A46"
        document.getElementsByClassName('unchecked')[i+1].style.display = "block"
        document.getElementsByClassName('checked')[i+1].style.display = "none"
    }
}


// Customised funtion to check amount is valid
function checkCurrency(id){
    if (!(document.getElementById(id).value.includes("$"))) document.getElementById(id).value = "$"
    if (isNaN(document.getElementById(id).value.slice(1,document.getElementById(id).value.length))) showSnackbar("Invoice amount should be a number!")
    check_edit_cta()
}

// Add PopUp
function open_add() {
	document.getElementById('add_due_in_date').value = new Date().toISOString().substring(0, 10);
    document.getElementById("add_popup").style.display = "block"
}
function close_add() {
    document.getElementById("add_popup").style.display = "none"   
}
function reset_add() {
    document.getElementById("add_cust_name").value = ""
    document.getElementById("add_cust_number").value = ""
    document.getElementById("add_invoice_no").value = ""
    document.getElementById("add_invoice_amount").value = "$"
    document.getElementById("add_notes").value = ""
    document.getElementById('add_due_in_date').value = new Date().toISOString().substring(0, 10);
    check_add_cta()
}
// Change CTA color if all required input feilds are filled
function check_add_cta() {
    if (document.getElementById("add_cust_name").value.length == 0 || document.getElementById("add_cust_number").value.length == 0 || document.getElementById("add_invoice_no").value.length == 0 || isNaN(document.getElementById("add_invoice_amount").value.slice(1,document.getElementById("add_invoice_amount").value.length)) == true || document.getElementById("add_due_in_date").value.length <= 1) {
        console.log(document.getElementById("add_due_in_date").value)
        document.getElementById("add_save").style.background = "#97A1A9 0% 0% no-repeat padding-box"
        document.getElementById("add_save").style.border = "1px solid #97A1A9"
        return false;
    }
    else {
        document.getElementById("add_save").style.background = "#14AFF1 0% 0% no-repeat padding-box"
        document.getElementById("add_save").style.border = "1px solid #14AFF1"
        return true;
    }
}
// Click submit if feilds are filled, else show snckbar
function submit_add() {
    if (!check_add_cta()) showSnackbar("Mandatory fields can't be empty!")
    else document.getElementById("add_submitter").click()
}

// Edit PopUp
function close_edit() {
    document.getElementById("edit_popup").style.display = "none"   
}
function open_edit() {
    document.getElementById("edit_popup").style.display = "block"
    document.getElementById("edit_invoice_no").value = selected[0]["data"]["invoice_id"]
    document.getElementById("edit_invoice_amount").value = "$"+selected[0]["data"]["total_open_amount"]
    document.getElementById("edit_notes").value = (selected[0]["data"]["notes"] ? selected[0]["data"]["notes"] : "")
    check_edit_cta()
}
function reset_edit() {
    document.getElementById("edit_invoice_amount").value = "$"
    document.getElementById("edit_notes").value = ""
    check_edit_cta()
}
//Change CTA color if all required input feilds are filled
function check_edit_cta() {
    if (document.getElementById("edit_invoice_amount").value.length <= 1) {
        document.getElementById("edit_save").style.background = "#97A1A9 0% 0% no-repeat padding-box"
        document.getElementById("edit_save").style.border = "1px solid #97A1A9"
        return false
    }
    else {
        document.getElementById("edit_save").style.background = "#14AFF1 0% 0% no-repeat padding-box"
        document.getElementById("edit_save").style.border = "1px solid #14AFF1"
        return true
    }
}
//Click submit if feilds are filled, else show snckbar
function submit_edit() {
    if (!check_edit_cta()) showSnackbar("Mandatory fields can't be empty!")
    else document.getElementById("edit_submitter").click()
}


// Delete PopUp
function close_delete() {
    document.getElementById("delete_popup").style.display = "none"   
}
function open_delete() {
    document.getElementById("delete_popup").style.display = "block"
}
// Preparing data for pushing to Backend
function arrange_delete_data() {
    var delete_data = ""
    selected.forEach(el => {
        delete_data+=el['data']['invoice_id'] +","
    });
    document.getElementById("delete_data").value = delete_data;
    document.getElementById("delete_submitter").click()
}
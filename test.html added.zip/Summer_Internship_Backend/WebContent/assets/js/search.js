// Searching Data - Empty default
var search = "";

// Fetching Number of Pages Based on search results
const fetchSearchPages = () => {
    fetch("http://localhost:8080/H2HBABBA2746/getsearchpages/"+search)
        .then((res) => {
            return res.json()
        })
        .then((data) => {
        	console.log(data)
            setPage(data)
        })
}
 
// Initiating Search
function searchStart(){
	search = document.getElementById("search").value
	console.log(search)
	page=1
	
	document.getElementById('search_icon').style.opacity = '0'
	document.getElementById('search_icon').style.zIndex = '-1'
	document.getElementById('red_close_icon').style.zIndex = '1'
	document.getElementById('red_close_icon').style.opacity = '1'
		
	if (search == ""){
		document.getElementById('search_icon').style.opacity = '1'
		document.getElementById('search_icon').style.zIndex = '1'
		document.getElementById('red_close_icon').style.zIndex = '-1'
		document.getElementById('red_close_icon').style.opacity = '0'
	}
	
	fetchData()
}

// Fetch Data based on search results
const searchData = () => {
    fetch("http://localhost:8080/H2HBABBA2746/search/"+search+"-"+page)
        .then((res) => {
            return res.json()
        })
        .then((data) => {
            displayRows(data)
            fetchSearchPages()
        })
}


// Search Bar Color Changes
function searchFocus() {
 document.getElementById('search_bar').style.border = "1px solid #14AFF1"
}
function searchFocus1() {
 document.getElementById('search_bar').style.border = "1px solid #356680"
}
function changeSearchCursor() {
 if((document.getElementById('search').value).length > 0){
     document.getElementById('search_icon').style.cursor = 'pointer'
 }
 else{
     document.getElementById('search_icon').style.cursor = 'not-allowed'
 }
 
 searchStart()
}

// Clear Search bar Results
function clear_results(){
	search = ""
	document.getElementById("search").value = ""
	page = 1
	fetchData()
	document.getElementById('search_icon').style.opacity = '1'
	document.getElementById('search_icon').style.zIndex = '1'
	document.getElementById('red_close_icon').style.zIndex = '-1'
	document.getElementById('red_close_icon').style.opacity = '0'
}


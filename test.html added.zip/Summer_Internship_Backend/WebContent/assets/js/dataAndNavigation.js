// Initializing Empty Data and Page Numbers for the Invoice Table
var data = []
var page = 1, pages

// Navigation
// Navigation
// Navigation
// Navigation
// Navigation

// Fetch Number of Pages
const fetchPages = () => {
    fetch("http://localhost:8080/H2HBABBA2746/getpages")
        .then((res) => {
            return res.json()
        })
        .then((data) => {
            setPage(data)
        })
}
function setPage(datas) {
    pages = datas[0]['page']
    pagination_btns()
}

// Next Page Function
function nextPage() {
    if (page < pages) {
    	page = page + 1
        selected = []
        checkButtons()
        document.getElementsByClassName('unchecked')[0].style.display = "block"
        document.getElementsByClassName('checked')[0].style.display = "none"
    }
    console.log(page)
    pagination_btns()
    fetchData()
}

// Prev Page Function
function prevPage() {
    if (page > 1) { 
    	page = page - 1
        selected = []
        checkButtons()
        document.getElementsByClassName('unchecked')[0].style.display = "block"
        document.getElementsByClassName('checked')[0].style.display = "none"
    }
    console.log(page)
    pagination_btns()
    fetchData()
}

// Changing color of Naviation Buttons
function pagination_btns() {
	console.log(page, pages)
    if (page > 1){
        document.getElementsByClassName('leftArrow')[0].style.display = 'none'
        document.getElementsByClassName('leftArrow')[1].style.display = 'block'
    }
    else{
        document.getElementsByClassName('leftArrow')[0].style.display = 'block'
        document.getElementsByClassName('leftArrow')[1].style.display = 'none'
    }
    if (page == pages){
        document.getElementsByClassName('rightArrow')[1].style.display = 'none'
        document.getElementsByClassName('rightArrow')[0].style.display = 'block'
    }
    else{
        document.getElementsByClassName('rightArrow')[1].style.display = 'block'
        document.getElementsByClassName('rightArrow')[0].style.display = 'none'
    }
    if (pages == 0){
        document.getElementsByClassName('leftArrow')[0].style.display = 'block'
        document.getElementsByClassName('leftArrow')[1].style.display = 'none'
        document.getElementsByClassName('rightArrow')[1].style.display = 'none'
        document.getElementsByClassName('rightArrow')[0].style.display = 'block'
    }
}



// Data Fetching
// Data Fetching
// Data Fetching
// Data Fetching
// Data Fetching
        
// Fetch Data
const fetchData = () => {
	console.log(search)
//	Complete Data Fetching
	if (search == ""){
	    fetch("http://localhost:8080/H2HBABBA2746/fetch/"+page)
	        .then((res) => {
	            return res.json()
	        })
	        .then((data) => {
	        	console.log(data)
	            displayRows(data)
	            fetchPages()
	            pagination_btns()
	        })
	}
//	Fetch Data acc. to search bar input
	else searchData()
}
// To fetch Data on Load
fetchData();

// Display Rows in Invoice Table
function displayRows(datas) {
    data = datas
    
//  If Data Exists
    if (data.length > 0){
    	
    	document.getElementById('table').style.display = "block"
        document.getElementById('zero').style.display = "none"
    	
	    var table_rows = ""
	
	    for(var i=0; i<data.length; i++){
	        var p_date_flag = 0
	        var row_data = data[i]
	    
//	        Formatting Date Columns
	        var d_date = row_data.due_in_date.split("-");
	        if (row_data.pred_payment_date) {
	        	var p_date = row_data.pred_payment_date.split("-");
	        }
	        else p_date_flag = 1
	        var d = new Date();
	        console.log()
	
	        var months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sept", "Oct", "Nov", "Dec"]
	
//	        Formatting Amount
	        var amt_short = (parseInt(row_data.total_open_amount)/1000).toFixed(2)
	
//			Preparing Table Data
	        table_rows = table_rows + (
	
	            `<tr class='data_row'>
	                <td class='data checkbox'>
	                    <img src='assets/images/checkbox-outline.svg' alt='' class='unchecked' onclick='addData(${i})'/>
	                    <img src='assets/images/checkbox-filled.svg' alt='' class='checked' onclick='delData(${i})'/>
	                </td>
	                <td class='data cust_name'>${row_data.name_customer}</td>
	                <td class='data cust_no'>${row_data.cust_number}</td>
	                <td class='data invoice_no'>${row_data.invoice_id}</td>
	                <td class='data invoice_amt'>${amt_short}K</td>
	                <td class='data due_date' ${(Date.now() > new Date(d_date[0], d_date[1], d_date[2], 0, 0, 0, 0) && "style='color: #FF5B5B !important'")}>${d_date[2]}-${months[parseInt(d_date[1])-1]}-${d_date[0]}</td>
	                ${p_date_flag == 0 ? ("<td class='data pred_date' "+((Date.now() > new Date(p_date[0], p_date[1], p_date[2], 0, 0, 0, 0)) ? "style='color: #FF5B5B !important'" : "") + ">" + p_date[2]+"-"+months[p_date[1]-1]+"-"+p_date[0]+"</td>") : "<td class='data pred_date'>--</td>"}
	                <td class='data notes_column'><div class='notes'>${row_data.notes ? row_data.notes : "N/A"}</div></td>
	            </tr>`)
	        
	    }
    	
//    	Setting Table Data
	    document.getElementById('table').innerHTML = "<tr id='table_head' style='border-bottom: 1.5px solid #283A46'>" + document.getElementById('table_head').innerHTML + "</tr>" + table_rows;
    }
    
//  Zero Results Found
    else{
    	document.getElementById('table').style.display = "none"
        document.getElementById('zero').style.display = "block"
    	pagination_btns()
    }
}




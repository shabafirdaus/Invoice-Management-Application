// Creating customised function to Change CTA Button colors
function changeBtnColor(id, bg, color, dis) {
    document.getElementById(id).style.border = `1px solid ${bg}`;
    document.getElementById(id).style.color = color;
    document.getElementById(id).disabled = dis;
}

// CTA Button color checker
function checkButtons() {
//	Edit and Delete should be active
    if (selected.length == 1) {
        changeBtnColor("btn1", "#97A1A9", "#97A1A9", true)
        changeBtnColor("btn2", "#14AFF1", "#ffffff", false)
        changeBtnColor("btn3", "#14AFF1", "#ffffff", false)
        document.getElementById('plus_gray').style.display = 'inline'
        document.getElementById('plus_white').style.display = 'none'
        document.getElementById('edit_gray').style.display = 'none'
        document.getElementById('edit_white').style.display = 'inline'
        document.getElementById('minus_gray').style.display = 'none'
        document.getElementById('minus_white').style.display = 'inline'
    }
//  Delete should be active
    else if (selected.length > 1) {
        changeBtnColor("btn1", "#97A1A9", "#97A1A9", true)
        changeBtnColor("btn2", "#97A1A9", "#97A1A9", true)
        changeBtnColor("btn3", "#14AFF1", "#ffffff", false)
        document.getElementById('plus_gray').style.display = 'inline'
        document.getElementById('plus_white').style.display = 'none'
        document.getElementById('edit_gray').style.display = 'inline'
        document.getElementById('edit_white').style.display = 'none'
        document.getElementById('minus_gray').style.display = 'none'
        document.getElementById('minus_white').style.display = 'inline'
    } 
//  Add should be active
    else {
        changeBtnColor("btn1", "#14AFF1", "#ffffff", false)
        changeBtnColor("btn2", "#97A1A9", "#97A1A9", true)
        changeBtnColor("btn3", "#97A1A9", "#97A1A9", true)
        document.getElementById('plus_gray').style.display = 'none'
        document.getElementById('plus_white').style.display = 'inline'
        document.getElementById('edit_gray').style.display = 'inline'
        document.getElementById('edit_white').style.display = 'none'
        document.getElementById('minus_gray').style.display = 'inline'
        document.getElementById('minus_white').style.display = 'none'
    }
}

